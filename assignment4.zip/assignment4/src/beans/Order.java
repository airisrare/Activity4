package beans;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

@ManagedBean
@ViewScoped
public class Order {
	public String Order_Number = "";
	public String Product_Name  = "";
	public float Price = 0;
	public int Quantity = 0;
	
	public Order(String order_Number, String product_Name, float price, int quantity) {
		Order_Number = order_Number;
		Product_Name = product_Name;
		Price = price;
		Quantity = quantity;
	}

	public String getOrder_Number() {
		return Order_Number;
	}

	public void setOrder_Number(String order_Number) {
		Order_Number = order_Number;
	}

	public String getProduct_Name() {
		return Product_Name;
	}

	public void setProduct_Name(String product_Name) {
		Product_Name = product_Name;
	}

	public float getPrice() {
		return Price;
	}

	public void setPrice(float price) {
		Price = price;
	}

	public int getQuantity() {
		return Quantity;
	}

	public void setQuantity(int quantity) {
		Quantity = quantity;
	}
		
	
	

}
