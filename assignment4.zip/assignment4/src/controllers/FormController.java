package controllers;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

import Business.MyTimerService;
import Business.OrdersBusinessInterface;
import beans.User;

@ManagedBean
@ViewScoped
public class FormController 
{
	@Inject
	OrdersBusinessInterface services;
	
	@EJB
	MyTimerService timer;
	
	public String onSubmit(User user) {
		
//		FacesContext context = FacesContext.getCurrentInstance();
//		User user = context.getApplication().evaluateExpressionGet(context, "#{user}", User.class);
		
		System.out.println("Submit Clicked");
		System.out.println("FirstName" + user.getFirstName());
		System.out.println("LastName" + user.getLastName());
		
		
		//prints a message in the console to tell us which business service is currently selected
		services.test();
		
		//start a timer when login is clicked, milliseconds
		timer.setTimer(5000);
		
		//Forward to Test Response View along with the user Managed Bean
		FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("user", user);
		return "Response.xhtml";
	}
	
	
//	private void getAllOrders() {
//		
//		
//		
//	}
//	
//	
//	public String onRegSubmit() {
//		
//		return "";
//	}
//	
	public OrdersBusinessInterface getService() {
		return services;
		
	}

}
