package Business;

import javax.ejb.Local;
import java.util.List;
import beans.Order;


@Local
public interface OrdersBusinessInterface
{
//Add a local public void test()
	public void test();
	
	public List<Order>getOrders();
	
	public void setOrders(List<Order>orders);
	

}


