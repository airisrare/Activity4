package Business;

import java.util.ArrayList;
import java.util.List;
import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;

import beans.Order;

/**
 * Session Bean implementation class OrdersBusinessService
 */
@Stateless
@Local(OrdersBusinessInterface.class)
@Alternative
public class OrdersBusinessService implements OrdersBusinessInterface {
	List<Order> orders = new ArrayList<Order>();

	/**
	 * @see OrdersBusinessInterface#test()
	 */
	public void test() {
		// TODO Auto-generated method stub
		System.out.println("This is a testtttt");
	}
	
    /**
     * Default constructor. 
     */
    public OrdersBusinessService() {
		// TODO Auto-generated constructor stub
    	orders.add(new Order("0001","offWhite Tee", 200.3f, 30));
		orders.add(new Order("0002","Nike Socks", 35.3f, 30));
		orders.add(new Order("0003","Obey Hoodie", 60.7f, 30));
		orders.add(new Order("0004","Balenciaga Speed trainers", 280.3f, 30));
		orders.add(new Order("0005","YSL Denim", 843.3f, 30));
		
    }


	@Override
	public List<Order> getOrders() {
		// TODO Auto-generated method stub
		return orders;
	}

	@Override
	public void setOrders(List<Order> orders) {
		// TODO Auto-generated method stub
		this.orders = orders;
	}

//	@Override
//	public void onSubmit() {
//		// TODO Auto-generated method stub
//		
//	}

}
